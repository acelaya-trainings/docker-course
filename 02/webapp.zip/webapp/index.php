<?php
namespace Acelaya;

echo sprintf('Hello world!! [%s]', PHP_VERSION);

